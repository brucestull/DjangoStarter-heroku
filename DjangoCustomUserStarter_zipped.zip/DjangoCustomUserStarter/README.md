# Django Starter with CustomUser and Docutils
* A pre-built CustomUser Ddjango starter. Has pre-built CustomUser( and a basic app).
* See [notes.md](notes.md) for my notes.


## Assumptions:
* User has an IDE already set up and useable.
* User has some version of Python installed.

## Process:
* [notes.md](notes.md)

## Resources:
* [Contact Info]() to be added
* Method: [CustomUser - Will Vincent - LearnDjango](https://learndjango.com/tutorials/django-custom-user-model)
* Docutils: [The Django admin documentation generator](https://docs.djangoproject.com/en/4.0/ref/contrib/admin/admindocs/)
